/* KHÔNG PRINT · 2026 · by Ngô Hải Đăng
   Trình soạn thảo hoạt động cục bộ. Giao thức BLE 51 78 dành cho MỘT SỐ
   model máy in mini AE30/AE01/AE02; chưa được kiểm thử trên máy của người dùng. */
'use strict';
const $ = id => document.getElementById(id);
const PAPER_WIDTH = 384;
const SERVICE_UUID = '0000ae30-0000-1000-8000-00805f9b34fb';
const WRITE_UUID = '0000ae01-0000-1000-8000-00805f9b34fb';
const NOTIFY_UUID = '0000ae02-0000-1000-8000-00805f9b34fb';
const wait = ms => new Promise(resolve => setTimeout(resolve, ms));
let state = { image: null, alignment: 'left', bleDevice: null, writeCharacteristic: null, notifyCharacteristic: null, isPrinting: false, lastRaster: null, history: [] };
let toastTimer;
let renderScheduled = false;

function notify(message, error = false) {
  const el = $('toast');
  clearTimeout(toastTimer);
  el.textContent = message;
  el.className = `${error ? 'error ' : ''}show`;
  toastTimer = setTimeout(() => { el.className = ''; }, error ? 7200 : 4500);
}
function setTab(tab) {
  const image = tab === 'image';
  $('imageTab').classList.toggle('active', image);
  $('textTab').classList.toggle('active', !image);
  $('imageTab').setAttribute('aria-selected', image ? 'true' : 'false');
  $('textTab').setAttribute('aria-selected', image ? 'false' : 'true');
  $('imageTools').classList.toggle('hidden', !image);
  $('textTools').classList.toggle('hidden', image);
}
function openDialog(kicker, title, contentHTML) {
  $('dialogKicker').textContent = kicker;
  $('dialogTitle').textContent = title;
  $('dialogBody').innerHTML = contentHTML;
  $('infoDialog').showModal();
}
function showHistory() {
  const body = $('dialogBody');
  openDialog('NHẬT KÝ CỤC BỘ', 'Lịch sử gửi lệnh in', '');
  if (!state.history.length) { body.textContent = 'Chưa có bản in nào được ghi nhận trên trình duyệt này.'; return; }
  const list = document.createElement('ul');
  for (const entry of state.history.slice().reverse()) {
    const item = document.createElement('li');
    item.textContent = `${new Date(entry.time).toLocaleString('vi-VN')} — ${entry.device} · ${entry.width} × ${entry.height} px · ${entry.copies} bản (đã gửi dữ liệu)`;
    list.appendChild(item);
  }
  body.appendChild(list);
  const clear = document.createElement('button');
  clear.textContent = 'Xóa lịch sử cục bộ';
  clear.className = 'button button-outline';
  clear.addEventListener('click', () => { state.history = []; localStorage.removeItem('khongprint_history'); showHistory(); });
  body.appendChild(clear);
}
function openNavigation(section) {
  if (section === 'image' || section === 'text' || section === 'workspace') {
    setTab(section === 'text' ? 'text' : 'image');
    document.querySelector('.workspace-header').scrollIntoView({ behavior: 'smooth', block: 'start' });
  } else if (section === 'history') showHistory();
  else if (section === 'device') {
    openDialog('THIẾT BỊ', 'Kết nối Bluetooth', `<p>Website hỗ trợ thử nghiệm giao thức mini printer <strong>51 78</strong> với dịch vụ BLE <code>AE30</code> và đặc tính ghi <code>AE01</code>.</p><ul><li>Bật máy in và bật Bluetooth trên Windows.</li><li>Đóng ứng dụng điện thoại đang kết nối máy in.</li><li>Dùng Chrome hoặc Edge phiên bản mới, mở website bằng HTTPS (hoặc localhost).</li><li>Bấm “Kết nối Bluetooth” trên đầu trang để chọn thiết bị.</li><li>Nếu báo không tìm thấy dịch vụ AE30, model cần bổ sung giao thức riêng.</li></ul><p>Hiện tại: <strong>${state.bleDevice?.gatt?.connected ? 'Đã kết nối — ' + state.bleDevice.name : 'Chưa kết nối'}</strong>.</p>`);
  } else if (section === 'help') {
    openDialog('HƯỚNG DẪN', 'In ảnh & văn bản từ Windows', '<p><strong>1.</strong> Chọn thẻ Hình ảnh, tải ảnh và chỉnh sáng / tương phản / nét, rồi chọn cách chuyển sang đen trắng.</p><p><strong>2.</strong> Chọn thẻ Văn bản, nhập chữ, chọn phông, cỡ chữ, căn lề. Có thể kết hợp ảnh và chữ trong cùng bản in.</p><p><strong>3.</strong> Quan sát bản in trong khung xem trước, tải PNG để đối chiếu.</p><p><strong>4.</strong> Bật máy in, nhấn Kết nối Bluetooth và chọn đúng thiết bị.</p><p><strong>5.</strong> Chọn độ đậm rồi bấm Bắt đầu in. Nếu máy không chạy, xem model dưới đáy máy để bổ sung giao thức phù hợp.</p><p><em>Lưu ý:</em> độ sắc nét phần mềm không thể tăng độ phân giải vật lý của đầu in.</p>');
  } else if (section === 'admin') {
    openDialog('OWNER & DEVELOPMENT', 'Thông tin quản trị', '<p><strong>Ngô Hải Đăng là người lập trình trang web này và điều khiển mọi thông tin admin.</strong></p><p>KHÔNG PRINT — giao diện studio in nhiệt mini chạy trực tiếp trên trình duyệt. Ảnh được xử lý cục bộ, không gửi đến máy chủ.</p><p><strong>Bảo mật:</strong> Đây là mục giới thiệu người quản trị, <em>không phải hệ thống đăng nhập/admin có xác thực</em>. Để quản trị nhiều người dùng hoặc nội dung trên máy chủ, cần bổ sung backend, tài khoản và phân quyền.</p>');
  }
  document.querySelectorAll('.nav-link').forEach(el => el.classList.toggle('active', el.dataset.nav === section));
  $('breadcrumbCurrent').textContent = ({image:'In hình ảnh',text:'In văn bản',workspace:'Studio thiết kế',device:'Thiết bị',history:'Lịch sử',admin:'Quản trị',help:'Hướng dẫn'})[section] || 'Studio thiết kế';
}
function clamp(v, min, max) { return Math.max(min, Math.min(max, v)); }
function val(id) { return Number($(id).value); }
function configuredFont() {
  const family = $('fontFamily').value;
  return `${$('boldText').checked ? 700 : 400} ${val('fontSize')}px ${family === 'monospace' ? 'monospace' : `"${family}"`}`;
}
function textLines(ctx, rawText, maxWidth) {
  const lines = [];
  const paragraphs = rawText.replace(/\r/g,'').split('\n').slice(0, 150);
  for (const par of paragraphs) {
    if (!par.trim()) { lines.push(''); continue; }
    let line = '';
    for (const word of par.split(/\s+/)) {
      const candidate = line ? `${line} ${word}` : word;
      if (ctx.measureText(candidate).width <= maxWidth) { line = candidate; continue; }
      if (line) { lines.push(line); line = ''; }
      if (ctx.measureText(word).width <= maxWidth) { line = word; continue; }
      let unit = '';
      for (const chr of Array.from(word)) {
        if (ctx.measureText(unit + chr).width > maxWidth && unit) { lines.push(unit); unit = ''; }
        unit += chr;
      }
      line = unit;
    }
    lines.push(line);
  }
  return lines.slice(0, 115);
}
function transformedImage() {
  if (!state.image || !$('includeImage').checked) return null;
  const source = state.image;
  const deg = val('rotation');
  const rotated = deg === 90 || deg === 270;
  const ratio = rotated ? source.naturalHeight / source.naturalWidth : source.naturalWidth / source.naturalHeight;
  const w = PAPER_WIDTH - 40;
  const h = $('imageLayout').value === 'square' ? w : clamp(Math.round(w / ratio), 34, 1350);
  const dest = document.createElement('canvas'); dest.width = w; dest.height = h;
  const c = dest.getContext('2d', {willReadFrequently:true});
  c.fillStyle = 'white'; c.fillRect(0,0,w,h);
  c.save(); c.translate(w/2,h/2); c.rotate(deg*Math.PI/180);
  const dw0 = rotated ? source.naturalHeight : source.naturalWidth;
  const dh0 = rotated ? source.naturalWidth : source.naturalHeight;
  const scale = $('imageLayout').value === 'square' ? Math.max(w/dw0,h/dh0) : Math.min(w/dw0,h/dh0);
  // After a rotation, the local drawing rectangle must have the source's original orientation.
  const drawW = source.naturalWidth * scale, drawH = source.naturalHeight * scale;
  c.drawImage(source, -drawW/2, -drawH/2, drawW, drawH);
  c.restore();
  applyImageAdjustments(c, w, h);
  return dest;
}
function applyImageAdjustments(ctx, w, h) {
  const image = ctx.getImageData(0,0,w,h);
  const pixels = image.data;
  const brightness = val('brightness') * 2;
  const contrastFactor = (259*(val('contrast')+255)) / (255*(259-val('contrast')));
  for(let i=0;i<pixels.length;i+=4) {
    for(let c=0;c<3;c++) {
      let v = pixels[i+c];
      v = contrastFactor*(v-128)+128+brightness;
      if($('invertImage').checked) v=255-v;
      pixels[i+c] = clamp(Math.round(v),0,255);
    }
  }
  const sharp = val('sharpness')/100;
  if (sharp > 0) {
    const copy = new Uint8ClampedArray(pixels);
    const amount = sharp*1.8;
    for(let y=1;y<h-1;y++)for(let x=1;x<w-1;x++) {
      const i=(y*w+x)*4;
      for(let ch=0;ch<3;ch++) {
        const near = (copy[i-4+ch]+copy[i+4+ch]+copy[i-w*4+ch]+copy[i+w*4+ch])/4;
        pixels[i+ch] = clamp(Math.round(copy[i+ch]+amount*(copy[i+ch]-near)),0,255);
      }
    }
  }
  ctx.putImageData(image,0,0);
}
function buildComposite() {
  const margin = 20;
  const includeText = $('includeText').checked && $('textContent').value.length > 0;
  const measuring = document.createElement('canvas').getContext('2d');
  measuring.font = configuredFont();
  const lines = includeText ? textLines(measuring, $('textContent').value, PAPER_WIDTH - margin*2) : [];
  const fontSize = val('fontSize'), lineHeight = Math.round(fontSize*1.43);
  const textH = lines.length ? lines.length*lineHeight+18 : 0;
  const imageCanvas = transformedImage();
  const imageH = imageCanvas ? imageCanvas.height + 14 : 0;
  const total = clamp(25 + textH + imageH + 32, 145, 1950);
  const canvas = document.createElement('canvas'); canvas.width=PAPER_WIDTH;canvas.height=total;
  const ctx = canvas.getContext('2d',{willReadFrequently:true});
  ctx.fillStyle='#fff';ctx.fillRect(0,0,canvas.width,canvas.height);
  let currentY=24;
  const drawImage = () => { if (imageCanvas) {ctx.drawImage(imageCanvas,margin,currentY); currentY += imageH;} };
  const drawText = () => {
    if(!lines.length) return;
    ctx.font=configuredFont();ctx.textBaseline='top';ctx.fillStyle='#101010';ctx.textAlign=state.alignment;
    const x=state.alignment==='left' ? margin : state.alignment==='right' ? PAPER_WIDTH-margin : PAPER_WIDTH/2;
    for (const line of lines) {ctx.fillText(line,x,currentY); currentY += lineHeight;}
    currentY += 18;
  };
  if ($('imagePosition').value==='before'){drawImage();drawText();} else {drawText();drawImage();}
  if(!imageCanvas && !includeText) {
    ctx.fillStyle='#8f8f8f';ctx.font='15px Arial';ctx.textAlign='center';ctx.fillText('Chưa có nội dung để in',PAPER_WIDTH/2,75);
  }
  return canvas;
}
function ditherToMono(canvas) {
  const ctx=canvas.getContext('2d',{willReadFrequently:true});
  const image=ctx.getImageData(0,0,canvas.width,canvas.height);
  const data=image.data,w=canvas.width,h=canvas.height;
  const gray=new Float32Array(w*h);
  for(let i=0;i<gray.length;i++){const p=i*4;gray[i]=.299*data[p]+.587*data[p+1]+.114*data[p+2];}
  const mode=$('dither').value, threshold=val('threshold');
  const bayer=[0,8,2,10,12,4,14,6,3,11,1,9,15,7,13,5];
  const diffuse=(x,y,error,factor)=>{if(x<0||x>=w||y>=h)return;gray[y*w+x]+=error*factor;};
  for(let y=0;y<h;y++)for(let x=0;x<w;x++) {
    const k=y*w+x, old=gray[k];
    const cutoff= mode==='bayer' ? threshold + (bayer[(y%4)*4+(x%4)]-7.5)*8 : threshold;
    const next=old<cutoff?0:255;
    gray[k]=next;
    const err=old-next;
    if(mode==='floyd'){diffuse(x+1,y,err,7/16);diffuse(x-1,y+1,err,3/16);diffuse(x,y+1,err,5/16);diffuse(x+1,y+1,err,1/16);}
    if(mode==='atkinson'){
      for(const [dx,dy] of [[1,0],[2,0],[-1,1],[0,1],[1,1],[0,2]]) diffuse(x+dx,y+dy,err,1/8);
    }
  }
  for(let i=0;i<gray.length;i++) {const p=i*4;const v=gray[i];data[p]=v;data[p+1]=v;data[p+2]=v;data[p+3]=255;}
  ctx.putImageData(image,0,0);
  return canvas;
}
function renderPreview() {
  renderScheduled=false;
  try {
    const canvas=ditherToMono(buildComposite());
    const preview=$('previewCanvas');preview.width=canvas.width;preview.height=canvas.height;
    preview.getContext('2d',{willReadFrequently:true}).drawImage(canvas,0,0);
    state.lastRaster=preview;
    $('printSize').textContent=`${canvas.width} × ${canvas.height} px`;
    const title = ({'atkinson':'Atkinson','floyd':'Floyd–Steinberg','threshold':'Ngưỡng','bayer':'Bayer 4×4'})[$('dither').value];
    $('printMode').textContent=title+' · 1-bit';
  } catch(error) {console.error('Không thể cập nhật bản xem trước:',error);notify('Lỗi xử lý ảnh: '+error.message,true);}
}
function scheduleRender() {if(!renderScheduled){renderScheduled=true;requestAnimationFrame(renderPreview);}}
async function readFile(file) {
  if(!file)return;
  if (!file.type.startsWith('image/')) { notify('Hãy chọn tệp hình ảnh PNG, JPG hoặc WEBP.',true);return; }
  if(file.size>20*1024*1024){notify('Ảnh vượt quá 20 MB. Hãy chọn ảnh nhỏ hơn.',true);return;}
  const url=URL.createObjectURL(file),image=new Image();
  image.onload=()=>{URL.revokeObjectURL(url);state.image=image;$('uploadName').textContent=file.name;$('includeImage').checked=true;scheduleRender();notify('Đã tải ảnh: '+file.name);};
  image.onerror=()=>{URL.revokeObjectURL(url);notify('Không thể mở định dạng ảnh này.',true);};
  image.src=url;
}
function updateSliders() {
  for(const id of ['brightness','contrast','sharpness','threshold']) $(id+'Value').textContent=$(id).value;
  $('densityValue').textContent=val('density')+'/10';
  $('copiesValue').textContent=val('copies')+' bản';
  $('feedValue').textContent=val('feed')+' bước';
}
function updateConnectedUI(){
  const connected=!!state.bleDevice?.gatt?.connected && !!state.writeCharacteristic;
  $('connectionPill').classList.toggle('connected',connected);
  $('connectionLabel').textContent=connected ? 'Đã kết nối' : 'Chưa kết nối';
  $('deviceName').textContent=connected ? (state.bleDevice.name||'Máy in BLE') : 'Chưa có máy in';
  $('deviceSub').textContent=connected ? 'BLE AE30 · Sẵn sàng thử in' : 'Kết nối Bluetooth để bắt đầu';
  $('deviceLed').classList.toggle('on',connected);
  $('connectBtn').textContent=connected ? '✓ Đã kết nối' : 'ᛒ Kết nối Bluetooth';
  $('connectBtn').disabled=state.isPrinting;
  $('disconnectBtn').disabled=!connected||state.isPrinting;
}
async function connectBluetooth() {
  if(state.bleDevice?.gatt?.connected&&state.writeCharacteristic){notify('Máy in đã kết nối Bluetooth.');return;}
  if(!window.isSecureContext || !navigator.bluetooth){
    notify('Trình duyệt không hỗ trợ Web Bluetooth tại địa chỉ này. Dùng Chrome/Edge trên HTTPS hoặc http://localhost.',true);return;
  }
  $('connectBtn').disabled=true;
  try {
    // BẮT BUỘC gọi requestDevice ngay trong sự kiện click (user gesture).
    const device=await navigator.bluetooth.requestDevice({acceptAllDevices:true, optionalServices:[SERVICE_UUID]});
    const server=await device.gatt.connect();
    const service=await server.getPrimaryService(SERVICE_UUID);
    const write=await service.getCharacteristic(WRITE_UUID);
    let notification=null;
    try {
      notification=await service.getCharacteristic(NOTIFY_UUID);
      await notification.startNotifications();
      notification.addEventListener('characteristicvaluechanged',event=>{
        const val=event.target.value;
        if(val&&val.byteLength>0){console.debug('Nhận BLE notify:',Array.from(new Uint8Array(val.buffer,val.byteOffset,val.byteLength)).map(b=>b.toString(16).padStart(2,'0')).join(' '));}
      });
    } catch(error) {
      console.warn('Không bật được thông báo trạng thái BLE:', error);
      notify('Đã thấy AE30 nhưng không thể đăng ký trạng thái AE02; một số dòng máy sẽ không in được.',true);
    }
    state.bleDevice=device;state.writeCharacteristic=write;state.notifyCharacteristic=notification;
    device.addEventListener('gattserverdisconnected',()=>{state.writeCharacteristic=null;state.notifyCharacteristic=null;updateConnectedUI();notify('Bluetooth đã ngắt kết nối.',true);});
    updateConnectedUI();
    notify(`Đã kết nối ${device.name||'máy in BLE'}! Hãy thử in một đoạn văn ngắn.`);
  } catch(error) {
    console.error('Lỗi Bluetooth:',error);
    if(error.name!=='NotFoundError') notify(`Không kết nối được: ${error.message}. Thiết bị có thể không dùng giao thức AE30.`,true);
    else notify('Bạn đã hủy chọn máy in hoặc không tìm thấy thiết bị Bluetooth.');
    try {if(state.bleDevice?.gatt?.connected&&!state.writeCharacteristic)state.bleDevice.gatt.disconnect();}catch{}
  } finally {updateConnectedUI();}
}
function disconnectBluetooth(){
  if(state.bleDevice?.gatt?.connected)state.bleDevice.gatt.disconnect();
  state.writeCharacteristic=null;state.notifyCharacteristic=null;updateConnectedUI();
}
function crc8(payload){
  let crc=0;
  for(const byte of payload){crc^=byte;for(let i=0;i<8;i++)crc=(crc&0x80)?((crc<<1)^0x07)&0xff:(crc<<1)&0xff;}
  return crc;
}
function packet(opcode,payload=[]){
  const len=payload.length;
  return Uint8Array.from([0x51,0x78,opcode,0x00,len&255,(len>>8)&255,...payload,crc8(payload),0xff]);
}
function makeJob(canvas) {
  const w=canvas.width,h=canvas.height;
  if(w!==PAPER_WIDTH)throw Error('Độ rộng ảnh phải là 384 px.');
  const pixels=canvas.getContext('2d',{willReadFrequently:true}).getImageData(0,0,w,h).data;
  const commands=[];
  const energy=clamp(Math.round(17520*val('density')/8),1,65535);
  commands.push(packet(0xa3,[0]),packet(0xa4,[0x33]),packet(0xaf,[energy&255,(energy>>8)&255]),packet(0xbe,[0]),packet(0xbd,[0x23]));
  for(let y=0;y<h;y++){
    const row=new Uint8Array(48);
    for(let x=0;x<w;x++) if(pixels[(y*w+x)*4]<128)row[x>>3]|=1<<(7-(x&7));
    commands.push(packet(0xa2,row));
  }
  for(let i=0;i<val('feed');i++)commands.push(packet(0xbd,[0x23]));
  const byteCount=commands.reduce((a,p)=>a+p.length,0);
  const stream=new Uint8Array(byteCount);
  let offset=0;for(const p of commands){stream.set(p,offset);offset+=p.length;}
  return stream;
}
function setProgress(progress,message){
  $('printProgress').classList.remove('hidden');
  $('progressBar').style.width=progress+'%';
  $('progressPercent').textContent=progress+'%';
  $('progressText').textContent=message;
}
async function sendJob(bytes){
  const characteristic=state.writeCharacteristic;
  if(!characteristic)throw Error('Không có đặc tính BLE ghi dữ liệu');
  const chunkSize=160;
  const delay=bytes.length>20000?26:14;
  let number=0;
  for(let offset=0;offset<bytes.length;offset+=chunkSize){
    if(!state.bleDevice?.gatt?.connected)throw Error('Máy in đã ngắt kết nối giữa chừng');
    const part=bytes.slice(offset,offset+chunkSize);
    if(characteristic.properties.writeWithoutResponse&&characteristic.writeValueWithoutResponse){
      await characteristic.writeValueWithoutResponse(part);
    }else if(characteristic.properties.write&&characteristic.writeValueWithResponse){
      await characteristic.writeValueWithResponse(part);
    }else throw Error('Đặc tính AE01 không cho phép ghi');
    number++;
    if(number%3===0||offset+part.length===bytes.length)setProgress(Math.round((offset+part.length)/bytes.length*100),'Đang truyền lệnh qua Bluetooth...');
    await wait(delay);
    if(number%90===0)await wait(150);
  }
}
async function doPrint(){
  if(state.isPrinting)return;
  if(!state.bleDevice?.gatt?.connected||!state.writeCharacteristic){notify('Hãy nhấn Kết nối Bluetooth và chọn máy in trước.',true);return;}
  if(!$('includeText').checked && !$('includeImage').checked || (!$('textContent').value.trim() && !state.image)) {notify('Hãy nhập văn bản hoặc tải ảnh trước khi in.',true);return;}
  state.isPrinting=true;
  $('printBtn').disabled=true;
  $('printBtnText').textContent='Đang gửi dữ liệu...';
  updateConnectedUI();
  try {
    renderPreview();
    const job=makeJob(state.lastRaster);
    for(let i=0;i<val('copies');i++){
      setProgress(0,`Bản ${i+1}/${val('copies')} · Đang chuẩn bị`);
      await sendJob(job);
      await wait(650);
    }
    setProgress(100,'Đã truyền dữ liệu tới máy in');
    state.history.push({time:Date.now(),device:state.bleDevice?.name||'Máy in BLE',width:384,height:state.lastRaster.height,copies:val('copies')});
    state.history=state.history.slice(-50);
    try{localStorage.setItem('khongprint_history',JSON.stringify(state.history));}catch{}
    notify('Đã gửi lệnh in qua Bluetooth. Kiểm tra giấy để xác nhận bản in thực tế.');
  }catch(error){console.error('In lỗi:',error);setProgress(0,'Truyền dữ liệu thất bại');notify('Lỗi gửi lệnh in: '+error.message,true);}
  finally{state.isPrinting=false;$('printBtn').disabled=false;$('printBtnText').textContent='Bắt đầu in';updateConnectedUI();}
}
function downloadPNG(){
  renderPreview();
  const a=document.createElement('a');a.download='khong-print-'+new Date().toISOString().slice(0,10)+'.png';a.href=$('previewCanvas').toDataURL('image/png');a.click();
  notify('Đã tạo ảnh PNG của bản in.');
}
function resetControls(){
  for(const [id,value] of Object.entries({brightness:0,contrast:0,sharpness:0,threshold:128,dither:'atkinson',density:8,copies:1,feed:40,rotation:0,imageLayout:'fit',imagePosition:'before',fontFamily:'Arial',fontSize:22}))$(id).value=value;
  $('invertImage').checked=false;$('includeImage').checked=true;$('includeText').checked=true;$('boldText').checked=true;
  state.alignment='left';
  document.querySelectorAll('#alignmentGroup button').forEach(b=>b.classList.toggle('active',b.dataset.align==='left'));
  updateSliders();scheduleRender();notify('Đã đưa thông số về mặc định, giữ nguyên nội dung đã nhập.');
}
function initialize(){
  try{const old=JSON.parse(localStorage.getItem('khongprint_history')||'[]');if(Array.isArray(old))state.history=old.slice(-50);}catch{}
  $('imageTab').addEventListener('click',()=>setTab('image'));
  $('textTab').addEventListener('click',()=>setTab('text'));
  document.querySelectorAll('.nav-link').forEach(el=>el.addEventListener('click',()=>openNavigation(el.dataset.nav)));
  $('dialogClose').addEventListener('click',()=>$('infoDialog').close());
  $('dialogOkay').addEventListener('click',()=>$('infoDialog').close());
  $('uploadInput').addEventListener('change',e=>readFile(e.target.files?.[0]));
  $('uploadDrop').addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();$('uploadInput').click();}});
  for(const name of ['dragover','dragenter'])$('uploadDrop').addEventListener(name,e=>{e.preventDefault();e.currentTarget.classList.add('dragover');});
  for(const name of ['dragleave','drop'])$('uploadDrop').addEventListener(name,e=>{e.preventDefault();e.currentTarget.classList.remove('dragover');});
  $('uploadDrop').addEventListener('drop',e=>readFile(e.dataTransfer?.files?.[0]));
  for(const id of ['brightness','contrast','sharpness','threshold','dither','rotation','imageLayout','imagePosition','invertImage','includeImage','includeText','fontFamily','fontSize','boldText','textContent']){
    $(id).addEventListener('input',()=>{updateSliders();scheduleRender();});
    $(id).addEventListener('change',scheduleRender);
  }
  for(const id of ['density','copies','feed'])$(id).addEventListener('input',updateSliders);
  document.querySelectorAll('#alignmentGroup button').forEach(b=>b.addEventListener('click',()=>{
    state.alignment=b.dataset.align;
    document.querySelectorAll('#alignmentGroup button').forEach(t=>t.classList.toggle('active',t===b));
    scheduleRender();
  }));
  $('connectBtn').addEventListener('click',connectBluetooth);
  $('disconnectBtn').addEventListener('click',disconnectBluetooth);
  $('printBtn').addEventListener('click',doPrint);
  $('downloadBtn').addEventListener('click',downloadPNG);
  $('resetBtn').addEventListener('click',resetControls);
  $('zoomBtn').addEventListener('click',()=>{
    renderPreview();
    const win=window.open('', '_blank');
    if(!win){notify('Hãy cho phép trình duyệt mở tab xem trước.',true);return;}
    const img=win.document.createElement('img');img.src=$('previewCanvas').toDataURL('image/png');img.style='display:block;width:384px;max-width:100%;margin:24px auto;image-rendering:pixelated;box-shadow:0 12px 45px #0007';
    win.document.title='KHÔNG PRINT — Xem trước 384px';win.document.body.style='margin:0;background:#171923;padding:20px;';win.document.body.appendChild(img);
  });
  updateSliders();updateConnectedUI();scheduleRender();
  if(crc8([0x33])!==0x99||crc8([0x70,0x44])!==0x79)console.error('CRC8 test vector thất bại');
}
document.addEventListener('DOMContentLoaded',initialize);
