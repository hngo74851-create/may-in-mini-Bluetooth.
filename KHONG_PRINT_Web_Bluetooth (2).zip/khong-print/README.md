# KHÔNG PRINT — Mini Bluetooth Print Studio

Website tĩnh (HTML/CSS/JavaScript, không cần cài Node hay backend) để soạn văn bản, chỉnh ảnh đen trắng, tạo ảnh PNG và **thử gửi lệnh in BLE cho một số máy in nhiệt mini**.

**Thông tin tác giả được hiển thị trên trang web:**
> Ngô Hải Đăng là người lập trình trang web này và điều khiển mọi thông tin admin.

## Mở website trên Windows

### Xem giao diện, chỉnh ảnh và văn bản
Mở `index.html` bằng trình duyệt Chrome/Edge. Nếu tính năng Bluetooth không có, hãy chạy localhost hoặc đăng lên HTTPS.

### Chạy ở localhost
Trong thư mục giải nén, mở Terminal và chạy:

```bash
python -m http.server 8000
```

Truy cập `http://localhost:8000` bằng Chrome hoặc Edge. (Python chỉ cần cho việc phục vụ file thử nghiệm; website triển khai công khai không cần Python.)

### Đưa lên tên miền/Google
- Cách dễ nhất: tạo kho GitHub công khai, tải ba file `index.html`, `styles.css`, `app.js` lên gốc kho và bật **Settings → Pages → Deploy from branch → main / root**.
- URL mặc định: `https://<ten-github>.github.io/<ten-repo>/` (HTTPS).
- Có thể cấu hình tên miền riêng trong Pages và DNS của tên miền. "Đăng lên Google" không tự tạo tên miền; bạn phải triển khai website lên hosting HTTPS và cấu hình DNS.
- Web Bluetooth thường được Chrome và Edge trên Windows hỗ trợ, nhưng phụ thuộc thiết bị, trình duyệt, giao thức và quyền cấp cho website.

## Cách thử in thật
1. Bật Bluetooth Windows và bật máy in mini, bảo đảm có giấy.
2. Ngắt kết nối máy in khỏi app điện thoại trước khi dùng website.
3. Nhấn **Kết nối Bluetooth** rồi chọn đúng máy in từ danh sách của Chrome/Edge.
4. Website thử truy cập **BLE service AE30**, **characteristic AE01** để ghi, **AE02** để nghe phản hồi.
5. Chọn tab Văn bản, nhập 1–2 dòng, bật "Thêm văn bản", đặt độ đậm 8, bấm **Bắt đầu in**.
6. Quan sát kết quả trên máy. Thông báo "đã gửi dữ liệu" không xác nhận giấy đã in thành công.

## Giới hạn quan trọng
- Có nhiều dòng mini printer trông giống nhau, dùng app Fun Print / Full Print / iPrint nhưng **không dùng cùng giao thức**. Bản này chỉ triển khai giao thức **51 78 / Tiny / SC03h** dùng trên một số BLE printer AE30. Với máy không có AE30 hoặc dùng giao thức riêng, sẽ phải bổ sung driver/protocol. Chỉ ảnh máy in chưa xác định được model.
- Chưa kiểm tra trên máy in cụ thể của người yêu cầu. Không cam kết in thật 100% cho máy chưa rõ model.
- Một số biến thể với cùng dịch vụ AE30 có lệnh in khác, không nên thử nhiều gói lệnh ngẫu nhiên.
- Độ sắc nét phần mềm, độ sáng và tương phản giúp xử lý ảnh nhưng **không tăng số chấm in vật lý**.
- Dữ liệu ảnh và văn bản nằm trong trình duyệt. Lịch sử chỉ giữ thông tin metadata cục bộ. Không có đăng nhập admin, máy chủ hay quản trị đa người dùng. Nếu cần trang admin thật, phải thêm backend và xác thực.
- Lệnh truyền Bluetooth cần thao tác trực tiếp của người dùng, trang HTTPS hoặc localhost và trình duyệt hỗ trợ Web Bluetooth. Người dùng luôn chọn và cấp quyền thiết bị.

## Tài liệu kỹ thuật đã tham khảo
- Web Bluetooth: https://developer.mozilla.org/en-US/docs/Web/API/Web_Bluetooth_API
- Chrome Web Bluetooth: https://developer.chrome.com/articles/bluetooth
- SC03h iPrint protocol: https://github.com/shubhambelbase/mini-print-studio/blob/main/iPrint_SC03h_Protocol_Documentation.md
- TinyTape (web BLE printer reference): https://github.com/Bloorgard/TinyTape

*Không liên kết chính thức với ứng dụng Fun Print/iPrint.*
